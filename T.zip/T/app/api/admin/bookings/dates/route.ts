/**
 * GET /api/admin/bookings/dates
 * Returns all exam_dates that have at least one shift (for calendar markers)
 */
import { withAdmin, ok, serverError } from "@/lib/utils/api";
import { createAdminClient } from "@/lib/supabase/server";

export const GET = withAdmin(async () => {
  const supabase = createAdminClient();
  const { data, error } = await supabase
    .from("exam_shifts")
    .select("exam_date, status, title")
    .order("exam_date");
  if (error) return serverError();

  // Deduplicate by date, keeping distinct statuses
  const map: Record<string, { date: string; statuses: string[]; title: string }> = {};
  (data ?? []).forEach((r: Record<string,string>) => {
    if (!map[r.exam_date]) map[r.exam_date] = { date: r.exam_date, statuses: [], title: r.title };
    if (!map[r.exam_date].statuses.includes(r.status)) map[r.exam_date].statuses.push(r.status);
  });

  return ok({ dates: Object.values(map) });
});
